const ThicknessPricing = require('../models/ThicknessPricing');

const addThicknessPricing = async (req, res) => {
  try {
    const {
      thickness,
      baseRatePerWt,
      transportation,
      loadingUnloading,
      margin,
    } = req.body;

  
    const taxRate = baseRatePerWt * 0.18;

  
    const finalRatePerKg =
      baseRatePerWt + taxRate + transportation + loadingUnloading + 2;

    
    const ratePerSqFt = finalRatePerKg * 0.74;

    
    const roundOff = Math.ceil(ratePerSqFt);

   
    const sellingPrice = roundOff + margin;

   
    const newPricing = new ThicknessPricing({
      thickness,
      baseRatePerWt,
      taxRate,
      transportation,
      loadingUnloading,
      finalRatePerKg,
      ratePerSqFt,
      roundOff,
      margin,
      sellingPrice,
    });

  
    const savedPricing = await newPricing.save();

    res.status(201).json({
      message: 'Thickness pricing added successfully',
      data: savedPricing,
    });
  } catch (error) {
    res.status(500).json({
      message: 'An error occurred while adding thickness pricing',
      error: error.message,
    });
  }
};



const editThicknessPricing = async (req, res) => {
    try {
      const { id } = req.params;
      const {
        thickness,
        baseRatePerWt,
        transportation,
        loadingUnloading,
        margin,
      } = req.body;
  
      
      const existingPricing = await ThicknessPricing.findById(id);
  
      if (!existingPricing) {
        return res.status(404).json({
          message: 'Thickness pricing record not found',
        });
      }
  
   
      const taxRate = baseRatePerWt * 0.18;
      const finalRatePerKg =
        baseRatePerWt + taxRate + transportation + loadingUnloading + 2;
      const ratePerSqFt = finalRatePerKg * 0.74;
      const roundOff = Math.ceil(ratePerSqFt);
      const sellingPrice = roundOff + margin;
  
     
      existingPricing.thickness = thickness || existingPricing.thickness;
      existingPricing.baseRatePerWt = baseRatePerWt || existingPricing.baseRatePerWt;
      existingPricing.taxRate = taxRate;
      existingPricing.transportation = transportation || existingPricing.transportation;
      existingPricing.loadingUnloading =
        loadingUnloading || existingPricing.loadingUnloading;
      existingPricing.finalRatePerKg = finalRatePerKg;
      existingPricing.ratePerSqFt = ratePerSqFt;
      existingPricing.roundOff = roundOff;
      existingPricing.margin = margin || existingPricing.margin;
      existingPricing.sellingPrice = sellingPrice;
  
     
      const updatedPricing = await existingPricing.save();
  
      res.status(200).json({
        message: 'Thickness pricing updated successfully',
        data: updatedPricing,
      });
    } catch (error) {
      res.status(500).json({
        message: 'An error occurred while updating thickness pricing',
        error: error.message,
      });
    }
  };
  
module.exports = { addThicknessPricing ,editThicknessPricing};
