const Transportation = require('../../../models/transportationModel'); 


const calculateTripCost = async (req, res) => {
  try {
    const { vehicleType, km, numberOfTrips } = req.body; 


    if (!vehicleType || !km || !numberOfTrips) {
      return res.status(400).json({ message: 'Vehicle type, kilometers, and number of trips are required.' });
    }

    if (numberOfTrips <= 0) {
      return res.status(400).json({ message: 'Number of trips must be greater than 0.' });
    }

    
    const vehicle = await Transportation.findOne({ vehicleType });

    if (!vehicle) {
      return res.status(404).json({ message: 'Vehicle type not found.' });
    }

    let costPerTrip;

   
    if (km <= vehicle.minKmCovered) {
      costPerTrip = vehicle.minCharge; 
    } else {
      const additionalKm = km - vehicle.minKmCovered;
      const additionalCharge = additionalKm * vehicle.perKmCharge;
      costPerTrip = vehicle.minCharge + additionalCharge;
    }

   
    const totalCost = costPerTrip * numberOfTrips;

   
    return res.status(200).json({
      vehicleType,
      km,
      numberOfTrips,
      costPerTrip,
      totalCost,
      message: `The total cost for ${numberOfTrips} trip(s) of ${km} km each with ${vehicleType} is ₹${totalCost}.`,
    });
  } catch (error) {
    console.error('Error calculating trip cost:', error);
    return res.status(500).json({ message: 'Internal server error' });
  }
};

const addTransportation = async (req, res) => {
    try {
      const { vehicleType, minCharge, minKmCovered, perKmCharge, petrolCharge } = req.body;
  
      
      if (!vehicleType || !minCharge || !minKmCovered || !perKmCharge) {
        return res.status(400).json({ message: 'All fields are required (vehicleType, minCharge, minKmCovered, perKmCharge).' });
      }
  
  
      const existingVehicle = await Transportation.findOne({ vehicleType });
      if (existingVehicle) {
        return res.status(400).json({ message: `Transportation type '${vehicleType}' already exists.` });
      }
  
     
      const newTransportation = new Transportation({
        vehicleType,
        minCharge,
        minKmCovered,
        perKmCharge,
        petrolCharge: petrolCharge || 115, 
      });
  
      await newTransportation.save();
  
      return res.status(201).json({ message: 'Transportation added successfully.', data: newTransportation });
    } catch (error) {
      console.error('Error adding transportation:', error);
      return res.status(500).json({ message: 'Internal server error.' });
    }
  };

 
const editTransportation = async (req, res) => {
    try {
      const { id } = req.params; 
      const { minCharge, minKmCovered, perKmCharge, petrolCharge } = req.body;
  
 
      if (!minCharge && !minKmCovered && !perKmCharge && !petrolCharge) {
        return res.status(400).json({ message: 'At least one field to update must be provided.' });
      }
  
      const updatedTransportation = await Transportation.findByIdAndUpdate(
        id,
        { $set: { minCharge, minKmCovered, perKmCharge, petrolCharge } },
        { new: true, runValidators: true } 
      );
  
      if (!updatedTransportation) {
        return res.status(404).json({ message: 'Transportation type not found.' });
      }
  
      return res.status(200).json({ message: 'Transportation updated successfully.', data: updatedTransportation });
    } catch (error) {
      console.error('Error updating transportation:', error);
      return res.status(500).json({ message: 'Internal server error.' });
    }
  };
  

module.exports = { calculateTripCost,addTransportation,editTransportation };
